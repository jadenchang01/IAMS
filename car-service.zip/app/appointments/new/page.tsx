"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { CalendarIcon, ChevronLeft } from "lucide-react"
import { format } from "date-fns"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { FormDescription, FormLabel } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"

export default function BookingPage() {
  const { toast } = useToast()
  const [date, setDate] = useState<Date>()
  const [step, setStep] = useState(1)
  const [formData, setFormData] = useState({
    service: "",
    vehicle: "",
    name: "",
    email: "",
    phone: "",
    notes: "",
  })

  const timeSlots = ["9:00 AM", "10:00 AM", "11:00 AM", "1:00 PM", "2:00 PM", "3:00 PM", "4:00 PM"]

  const handleChange = (field: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // In a real app, you would submit this data to your backend
    console.log("Booking data:", { ...formData, date })

    toast({
      title: "Appointment Booked!",
      description: `Your appointment has been scheduled for ${date ? format(date, "PPP") : ""} at ${formData.service}.`,
    })

    // Redirect to confirmation page (in a real app)
    // router.push("/appointments/confirmation")
  }

  const nextStep = () => setStep(step + 1)
  const prevStep = () => setStep(step - 1)

  return (
    <div className="container max-w-4xl px-4 py-12 mx-auto md:px-6">
      <Link href="/" className="flex items-center mb-8 text-sm text-gray-600 hover:text-red-600">
        <ChevronLeft className="w-4 h-4 mr-1" /> Back to Home
      </Link>

      <div className="mb-8">
        <h1 className="text-3xl font-bold">Book Your Service Appointment</h1>
        <p className="mt-2 text-gray-600">Schedule your vehicle service in just a few easy steps.</p>
      </div>

      <div className="mb-8">
        <div className="flex items-center justify-between max-w-md">
          {[1, 2, 3].map((i) => (
            <div key={i} className="flex flex-col items-center">
              <div
                className={cn(
                  "flex items-center justify-center w-10 h-10 rounded-full text-white mb-2",
                  step >= i ? "bg-red-600" : "bg-gray-300",
                )}
              >
                {i}
              </div>
              <span className="text-xs text-gray-600">{i === 1 ? "Service" : i === 2 ? "Date & Time" : "Details"}</span>
            </div>
          ))}
        </div>
      </div>

      <Card className="border-none shadow-lg">
        <CardHeader>
          <CardTitle>
            {step === 1 ? "Select Service" : step === 2 ? "Choose Date & Time" : "Your Information"}
          </CardTitle>
          <CardDescription>
            {step === 1
              ? "What service does your vehicle need?"
              : step === 2
                ? "When would you like to schedule your appointment?"
                : "Please provide your contact details"}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit}>
            {step === 1 && (
              <div className="space-y-4">
                <div className="space-y-2">
                  <FormLabel>Service Type</FormLabel>
                  <Select value={formData.service} onValueChange={(value) => handleChange("service", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a service" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="oil-change">Oil Change</SelectItem>
                      <SelectItem value="brake-service">Brake Service</SelectItem>
                      <SelectItem value="tire-rotation">Tire Rotation</SelectItem>
                      <SelectItem value="engine-diagnostics">Engine Diagnostics</SelectItem>
                      <SelectItem value="ac-service">A/C Service</SelectItem>
                      <SelectItem value="full-inspection">Full Inspection</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <FormLabel>Vehicle Information</FormLabel>
                  <Input
                    placeholder="Year, Make, Model (e.g., 2019 Honda Civic)"
                    value={formData.vehicle}
                    onChange={(e) => handleChange("vehicle", e.target.value)}
                  />
                  <FormDescription>
                    Please provide your vehicle details so we can better prepare for your service.
                  </FormDescription>
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-4">
                <div className="space-y-2">
                  <FormLabel>Appointment Date</FormLabel>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn("w-full justify-start text-left font-normal", !date && "text-muted-foreground")}
                      >
                        <CalendarIcon className="w-4 h-4 mr-2" />
                        {date ? format(date, "PPP") : "Select a date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={date}
                        onSelect={setDate}
                        initialFocus
                        disabled={(date) => {
                          const day = date.getDay()
                          // Disable weekends and past dates
                          return day === 0 || day === 6 || date < new Date(new Date().setHours(0, 0, 0, 0))
                        }}
                      />
                    </PopoverContent>
                  </Popover>
                  <FormDescription>We are open Monday-Friday, 8:00 AM - 6:00 PM.</FormDescription>
                </div>

                <div className="space-y-2">
                  <FormLabel>Preferred Time</FormLabel>
                  <Select value={formData.service} onValueChange={(value) => handleChange("service", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a time slot" />
                    </SelectTrigger>
                    <SelectContent>
                      {timeSlots.map((time) => (
                        <SelectItem key={time} value={time}>
                          {time}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-4">
                <div className="space-y-2">
                  <FormLabel>Full Name</FormLabel>
                  <Input
                    placeholder="John Smith"
                    value={formData.name}
                    onChange={(e) => handleChange("name", e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <FormLabel>Email Address</FormLabel>
                  <Input
                    type="email"
                    placeholder="john@example.com"
                    value={formData.email}
                    onChange={(e) => handleChange("email", e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <FormLabel>Phone Number</FormLabel>
                  <Input
                    type="tel"
                    placeholder="(555) 123-4567"
                    value={formData.phone}
                    onChange={(e) => handleChange("phone", e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <FormLabel>Additional Notes</FormLabel>
                  <Textarea
                    placeholder="Any specific issues or concerns about your vehicle..."
                    value={formData.notes}
                    onChange={(e) => handleChange("notes", e.target.value)}
                  />
                </div>
              </div>
            )}
          </form>
        </CardContent>
        <CardFooter className="flex justify-between">
          {step > 1 ? (
            <Button variant="outline" onClick={prevStep}>
              Back
            </Button>
          ) : (
            <div></div>
          )}

          {step < 3 ? (
            <Button className="bg-red-600 hover:bg-red-700" onClick={nextStep}>
              Continue
            </Button>
          ) : (
            <Button className="bg-red-600 hover:bg-red-700" onClick={handleSubmit}>
              Book Appointment
            </Button>
          )}
        </CardFooter>
      </Card>
    </div>
  )
}
