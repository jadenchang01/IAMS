"use client"
import Link from "next/link"
import { ScanLine, ClipboardList, LineChart } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function ServicesPage() {
  const services = [
    {
      id: "scan-registration",
      title: "Scan & Registration",
      description: "Quick vehicle scanning and registration services.",
      details:
        "Our scanning service provides comprehensive diagnostics of your vehicle's systems, followed by efficient registration processing to get you on the road quickly.",
      price: "From $39.99",
      icon: <ScanLine className="w-10 h-10 text-green-600" />,
    },
    {
      id: "maintenance-log",
      title: "Maintenance Log",
      description: "Track and manage your vehicle's maintenance history.",
      details:
        "Our maintenance logging system helps you keep track of all service records, upcoming maintenance needs, and provides detailed history for resale value.",
      price: "From $19.99",
      icon: <ClipboardList className="w-10 h-10 text-green-600" />,
    },
    {
      id: "maintenance-forecast",
      title: "Maintenance Demand Forecast",
      description: "Predict future maintenance needs based on vehicle data.",
      details:
        "Our advanced analytics system predicts when your vehicle will need maintenance based on usage patterns, helping you plan ahead and avoid unexpected breakdowns.",
      price: "From $29.99",
      icon: <LineChart className="w-10 h-10 text-green-600" />,
    },
  ]

  return (
    <div className="container px-4 py-12 mx-auto md:px-6 bg-gray-900 text-white">
      <div className="flex flex-col items-center mb-12 text-center">
        <h1 className="text-3xl font-bold">Our Services</h1>
        <p className="max-w-2xl mt-4 text-gray-300">
          We offer a comprehensive range of automotive services to keep your vehicle running smoothly and safely.
        </p>
      </div>

      <div className="grid gap-8 md:grid-cols-3">
        {services.map((service) => (
          <Link
            href={`/services/${service.id}`}
            key={service.id}
            className="block transition-transform hover:scale-105"
          >
            <Card className="h-full bg-gray-700 border-gray-600 hover:shadow-lg hover:shadow-green-900/20 cursor-pointer">
              <CardHeader>
                <div className="p-2 w-16 h-16 flex items-center justify-center rounded-full bg-gray-600 mb-4">
                  {service.icon}
                </div>
                <CardTitle className="text-white">{service.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300">{service.description}</p>
                <p className="mt-4 font-bold text-white">{service.price}</p>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      <div className="p-8 mt-12 bg-gray-800 rounded-lg">
        <div className="flex flex-col items-center text-center md:flex-row md:text-left md:justify-between">
          <div>
            <h2 className="text-2xl font-bold text-white">Need a Custom Service?</h2>
            <p className="mt-2 text-gray-300">Contact us to discuss your specific vehicle needs.</p>
          </div>
          <Link href="/contact" className="mt-4 md:mt-0">
            <Button className="bg-green-700 hover:bg-green-800 text-white">Contact Us</Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
