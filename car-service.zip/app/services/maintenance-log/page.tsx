"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { ArrowLeft, Search, ArrowUpDown, ChevronDown, ChevronUp, ClipboardList } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { useToast } from "@/hooks/use-toast"

// Sample maintenance log data
const maintenanceLogData = [
  {
    id: 1,
    licensePlate: "ABC-1234",
    entryDate: "2023-05-15",
    mileage: "45,230",
    loadCapacity: "1,100 lbs",
    details: "Regular oil change and filter replacement. Brake pads at 30%.",
  },
  {
    id: 2,
    licensePlate: "XYZ-7890",
    entryDate: "2023-06-22",
    mileage: "78,450",
    loadCapacity: "2,500 lbs",
    details: "Transmission fluid change. Replaced air filter. Tire rotation performed.",
  },
  {
    id: 3,
    licensePlate: "DEF-5678",
    entryDate: "2023-07-10",
    mileage: "32,120",
    loadCapacity: "1,800 lbs",
    details: "Engine diagnostic performed. Replaced spark plugs. Coolant system flushed.",
  },
  {
    id: 4,
    licensePlate: "GHI-9012",
    entryDate: "2023-08-05",
    mileage: "65,780",
    loadCapacity: "3,200 lbs",
    details: "Brake system overhaul. Replaced brake pads and rotors. Brake fluid changed.",
  },
  {
    id: 5,
    licensePlate: "JKL-3456",
    entryDate: "2023-09-18",
    mileage: "12,450",
    loadCapacity: "950 lbs",
    details: "First service. Oil change and multi-point inspection completed.",
  },
  {
    id: 6,
    licensePlate: "MNO-7890",
    entryDate: "2023-10-02",
    mileage: "98,760",
    loadCapacity: "1,500 lbs",
    details: "Major service. Timing belt replaced. Water pump replaced. Full fluid change.",
  },
  {
    id: 7,
    licensePlate: "PQR-1234",
    entryDate: "2023-11-15",
    mileage: "54,320",
    loadCapacity: "2,200 lbs",
    details: "Winter preparation. Antifreeze replaced. Winter tires installed. Battery tested.",
  },
  {
    id: 8,
    licensePlate: "ABC-1234",
    entryDate: "2023-12-20",
    mileage: "52,780",
    loadCapacity: "1,100 lbs",
    details: "Regular maintenance. Oil and filter change. Wiper blades replaced.",
  },
  {
    id: 9,
    licensePlate: "STU-5678",
    entryDate: "2024-01-08",
    mileage: "23,450",
    loadCapacity: "1,750 lbs",
    details: "Check engine light diagnosis. Oxygen sensor replaced. System reset.",
  },
  {
    id: 10,
    licensePlate: "VWX-9012",
    entryDate: "2024-02-14",
    mileage: "87,650",
    loadCapacity: "2,800 lbs",
    details: "Suspension system inspection. Replaced front struts. Wheel alignment performed.",
  },
]

type SortDirection = "asc" | "desc" | null
type SortField = "licensePlate" | "entryDate" | "mileage" | null

export default function MaintenanceLogPage() {
  const { toast } = useToast()
  const router = useRouter()
  const [searchTerm, setSearchTerm] = useState("")
  const [sortField, setSortField] = useState<SortField>(null)
  const [sortDirection, setSortDirection] = useState<SortDirection>(null)
  const [isLoggedIn, setIsLoggedIn] = useState(false)

  // Check authentication on page load
  useEffect(() => {
    // In a real app, this would check a token or session
    const loggedIn = localStorage.getItem("isLoggedIn") === "true"
    // \
    // setIsLoggedIn(loggedIn)em("isLoggedIn") === "true"
    setIsLoggedIn(loggedIn)

    if (!loggedIn) {
      toast({
        title: "Authentication Required",
        description: "Please log in to view this page",
      })
      router.push("/login")
    }
  }, [router, toast])

  // Handle sorting
  const handleSort = (field: SortField) => {
    if (sortField === field) {
      // Toggle direction if same field
      setSortDirection(sortDirection === "asc" ? "desc" : sortDirection === "desc" ? null : "asc")
      setSortField(sortDirection === "desc" ? null : field)
    } else {
      // New field, start with ascending
      setSortField(field)
      setSortDirection("asc")
    }
  }

  // Filter and sort data
  const filteredAndSortedData = maintenanceLogData
    .filter((entry) => {
      if (!searchTerm) return true

      const searchLower = searchTerm.toLowerCase()
      return (
        entry.licensePlate.toLowerCase().includes(searchLower) ||
        entry.entryDate.includes(searchLower) ||
        entry.mileage.toLowerCase().includes(searchLower) ||
        entry.loadCapacity.toLowerCase().includes(searchLower) ||
        entry.details.toLowerCase().includes(searchLower)
      )
    })
    .sort((a, b) => {
      if (!sortField || !sortDirection) return 0

      let comparison = 0
      if (sortField === "licensePlate") {
        comparison = a.licensePlate.localeCompare(b.licensePlate)
      } else if (sortField === "entryDate") {
        comparison = new Date(a.entryDate).getTime() - new Date(b.entryDate).getTime()
      } else if (sortField === "mileage") {
        const aMileage = Number.parseInt(a.mileage.replace(/,/g, ""))
        const bMileage = Number.parseInt(b.mileage.replace(/,/g, ""))
        comparison = aMileage - bMileage
      }

      return sortDirection === "asc" ? comparison : -comparison
    })

  // Render sort indicator
  const renderSortIndicator = (field: SortField) => {
    if (sortField !== field) return <ArrowUpDown className="ml-2 h-4 w-4" />
    if (sortDirection === "asc") return <ChevronUp className="ml-2 h-4 w-4" />
    if (sortDirection === "desc") return <ChevronDown className="ml-2 h-4 w-4" />
    return <ArrowUpDown className="ml-2 h-4 w-4" />
  }

  if (!isLoggedIn) {
    return null // Will redirect in useEffect
  }

  return (
    <div className="container px-4 py-12 mx-auto md:px-6 bg-gray-900 min-h-screen">
      <Link href="/" className="inline-flex items-center text-gray-400 hover:text-white mb-8">
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Home
      </Link>

      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center p-4 bg-gray-800 rounded-full mb-4">
            <ClipboardList className="h-10 w-10 text-green-600" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-4">Maintenance Log</h1>
          <p className="text-gray-300 max-w-2xl mx-auto">
            Track and manage your vehicle's complete maintenance history with our detailed logging system.
          </p>
        </div>

        <Card className="bg-gray-800 border-gray-700 mb-8">
          <CardHeader>
            <CardTitle className="text-white">Maintenance Records</CardTitle>
            <CardDescription className="text-gray-400">
              View and search through all maintenance entries for your vehicles
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="mb-6">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                <Input
                  type="search"
                  placeholder="Search maintenance records..."
                  className="pl-8 bg-gray-700 border-gray-600 text-white"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>

            <div className="rounded-md border border-gray-700 overflow-hidden">
              <Table>
                <TableHeader className="bg-gray-700">
                  <TableRow className="hover:bg-gray-700/50 border-gray-600">
                    <TableHead
                      className="text-gray-300 hover:text-white cursor-pointer"
                      onClick={() => handleSort("licensePlate")}
                    >
                      <div className="flex items-center">
                        License Plate
                        {renderSortIndicator("licensePlate")}
                      </div>
                    </TableHead>
                    <TableHead
                      className="text-gray-300 hover:text-white cursor-pointer"
                      onClick={() => handleSort("entryDate")}
                    >
                      <div className="flex items-center">
                        Entry Date
                        {renderSortIndicator("entryDate")}
                      </div>
                    </TableHead>
                    <TableHead
                      className="text-gray-300 hover:text-white cursor-pointer"
                      onClick={() => handleSort("mileage")}
                    >
                      <div className="flex items-center">
                        Mileage (km)
                        {renderSortIndicator("mileage")}
                      </div>
                    </TableHead>
                    <TableHead className="text-gray-300">Load Capacity</TableHead>
                    <TableHead className="text-gray-300 w-1/3">Details</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredAndSortedData.length > 0 ? (
                    filteredAndSortedData.map((entry) => (
                      <TableRow key={entry.id} className="hover:bg-gray-700/50 border-gray-600">
                        <TableCell className="font-medium text-white">{entry.licensePlate}</TableCell>
                        <TableCell className="text-gray-300">{entry.entryDate}</TableCell>
                        <TableCell className="text-gray-300">{entry.mileage}</TableCell>
                        <TableCell className="text-gray-300">{entry.loadCapacity}</TableCell>
                        <TableCell className="text-gray-300">{entry.details}</TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={5} className="h-24 text-center text-gray-400">
                        No maintenance records found.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>

            <div className="mt-4 text-right text-sm text-gray-400">
              Showing {filteredAndSortedData.length} of {maintenanceLogData.length} records
            </div>
          </CardContent>
        </Card>

        <div className="grid gap-6 md:grid-cols-2">
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Maintenance Tips</CardTitle>
            </CardHeader>
            <CardContent className="text-gray-300">
              <ul className="list-disc list-inside space-y-2">
                <li>Regular oil changes every 5,000-7,500 km can extend engine life</li>
                <li>Check tire pressure monthly for optimal fuel efficiency</li>
                <li>Replace air filters every 15,000-30,000 km</li>
                <li>Inspect brake pads every 10,000 km for safety</li>
                <li>Follow manufacturer's recommended maintenance schedule</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Add New Record</CardTitle>
            </CardHeader>
            <CardContent className="text-gray-300">
              <p className="mb-4">
                Keep your maintenance history up-to-date by adding new service records as they occur.
              </p>
              <Button
                className="w-full bg-green-700 hover:bg-green-800"
                onClick={() => router.push("/services/scan-registration")}
              >
                Add Maintenance Record
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
