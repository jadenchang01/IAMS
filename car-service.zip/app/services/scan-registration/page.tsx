"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { ScanLine, ArrowLeft, Loader2, CheckCircle, RotateCcw, Barcode, Info } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { useToast } from "@/hooks/use-toast"

// Dummy car data for the scan result
const dummyCarData = {
  model: "Camry",
  year: "2019",
  vin: "4T1BF1FK5GU123456",
  licensePlate: "ABC-1234",
  mileage: "45,230",
  loadCapacity: "1,100 lbs",
  recordedIssues: [
    { severity: "low", description: "Air filter needs replacement" },
    { severity: "medium", description: "Brake pads at 30%" },
  ],
}

type ScanState = "idle" | "scanning" | "results"

export default function ScanRegistrationPage() {
  const { toast } = useToast()
  const router = useRouter()
  const [scanState, setScanState] = useState<ScanState>("idle")
  const [showDialog, setShowDialog] = useState(false)
  const [carData, setCarData] = useState(dummyCarData)
  const [isLoggedIn, setIsLoggedIn] = useState(false)

  // Check authentication on page load
  useEffect(() => {
    // In a real app, this would check a token or session
    const loggedIn = localStorage.getItem("isLoggedIn") === "true"
    setIsLoggedIn(loggedIn)

    if (!loggedIn) {
      toast({
        title: "Authentication Required",
        description: "Please log in to view this page",
      })
      router.push("/login")
    }
  }, [router, toast])

  // Simulate scanning process
  const handleScan = () => {
    setScanState("scanning")

    // Simulate scanning delay
    setTimeout(() => {
      setScanState("results")
      setShowDialog(true)
    }, 2000)
  }

  const handleRescan = () => {
    setShowDialog(false)
    setScanState("idle")
    // In a real app, you might reset some state here
    setTimeout(() => {
      handleScan()
    }, 500)
  }

  const handleConfirm = () => {
    setShowDialog(false)
    setScanState("idle")
    toast({
      title: "Scan Confirmed",
      description: `Vehicle ${carData.model} (${carData.year}) has been registered successfully.`,
    })
  }

  if (!isLoggedIn) {
    return null // Will redirect in useEffect
  }

  return (
    <div className="container px-4 py-12 mx-auto md:px-6 bg-gray-900 min-h-screen">
      <Link href="/" className="inline-flex items-center text-gray-400 hover:text-white mb-8">
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Home
      </Link>

      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center p-4 bg-gray-800 rounded-full mb-4">
            <ScanLine className="h-10 w-10 text-green-600" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-4">Scan & Registration</h1>
          <p className="text-gray-300 max-w-2xl mx-auto">
            Our barcode scanning system quickly retrieves your vehicle information for efficient registration and
            maintenance tracking.
          </p>
        </div>

        <Card className="bg-gray-800 border-gray-700 mb-8">
          <CardHeader>
            <CardTitle className="text-white">Barcode Scanner</CardTitle>
            <CardDescription className="text-gray-400">
              Position the vehicle barcode in the scanning area and press the button below to begin
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center">
            <div className="w-full max-w-md aspect-video bg-gray-700 rounded-lg mb-6 flex items-center justify-center">
              {scanState === "scanning" ? (
                <div className="text-center">
                  <Loader2 className="h-16 w-16 text-green-600 animate-spin mx-auto mb-4" />
                  <p className="text-white">Scanning barcode...</p>
                </div>
              ) : (
                <div className="text-center">
                  <Barcode className="h-16 w-16 text-gray-500 mx-auto mb-4" />
                  <p className="text-gray-400">Barcode scan preview</p>
                </div>
              )}
            </div>

            <Button
              size="lg"
              className={`bg-green-700 hover:bg-green-800 text-white w-full max-w-xs ${
                scanState === "scanning" ? "opacity-50 cursor-not-allowed" : ""
              }`}
              onClick={handleScan}
              disabled={scanState === "scanning"}
            >
              {scanState === "scanning" ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Scanning...
                </>
              ) : (
                <>
                  <ScanLine className="mr-2 h-4 w-4" />
                  Scan Barcode
                </>
              )}
            </Button>
          </CardContent>
          <CardFooter className="text-sm text-gray-400 flex justify-center">
            <Info className="h-4 w-4 mr-2" />
            Make sure the barcode is clearly visible and properly positioned for accurate scanning
          </CardFooter>
        </Card>

        <div className="grid gap-6 md:grid-cols-2">
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">How It Works</CardTitle>
            </CardHeader>
            <CardContent className="text-gray-300">
              <ol className="list-decimal list-inside space-y-2">
                <li>Locate the barcode on your vehicle documentation</li>
                <li>Position the barcode in the scanning area</li>
                <li>Press the scan button to capture the barcode</li>
                <li>Review the retrieved vehicle information</li>
                <li>Confirm to complete registration or rescan if needed</li>
              </ol>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Benefits</CardTitle>
            </CardHeader>
            <CardContent className="text-gray-300">
              <ul className="list-disc list-inside space-y-2">
                <li>Instant data retrieval from barcode</li>
                <li>Eliminates manual data entry errors</li>
                <li>Quick access to vehicle specifications</li>
                <li>Seamless integration with registration system</li>
                <li>Retrieves complete vehicle history</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Scan Results Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="bg-gray-800 text-white border-gray-700 max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold flex items-center">
              <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
              Barcode Scan Complete
            </DialogTitle>
            <DialogDescription className="text-gray-400">
              The following vehicle information has been retrieved. Please confirm the information is correct.
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-x-4 gap-y-2">
              <div className="text-gray-400">Model:</div>
              <div className="text-white font-medium">{carData.model}</div>

              <div className="text-gray-400">Year:</div>
              <div className="text-white font-medium">{carData.year}</div>

              <div className="text-gray-400">VIN:</div>
              <div className="text-white font-medium">{carData.vin}</div>

              <div className="text-gray-400">License Plate:</div>
              <div className="text-white font-medium">{carData.licensePlate}</div>

              <div className="text-gray-400">Mileage:</div>
              <div className="text-white font-medium">{carData.mileage}</div>

              <div className="text-gray-400">Load Capacity:</div>
              <div className="text-white font-medium">{carData.loadCapacity}</div>
            </div>

            <div className="mt-2">
              <h4 className="text-white font-medium mb-2">Recorded Issues:</h4>
              <div className="bg-gray-700 rounded-md p-3">
                {carData.recordedIssues.map((issue, index) => (
                  <div key={index} className="flex items-center mb-2 last:mb-0">
                    <div
                      className={`w-2 h-2 rounded-full mr-2 ${
                        issue.severity === "low"
                          ? "bg-yellow-500"
                          : issue.severity === "medium"
                            ? "bg-orange-500"
                            : "bg-red-500"
                      }`}
                    />
                    <span className="text-gray-300">{issue.description}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <DialogFooter className="flex flex-col sm:flex-row gap-2">
            <Button
              variant="outline"
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
              onClick={handleRescan}
            >
              <RotateCcw className="mr-2 h-4 w-4" />
              Rescan
            </Button>
            <Button className="bg-green-700 hover:bg-green-800" onClick={handleConfirm}>
              <CheckCircle className="mr-2 h-4 w-4" />
              Confirm & Register
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
