"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { ArrowLeft, LineChart, Calendar, AlertTriangle, CheckCircle, Info, ChevronDown, ChevronUp } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { useToast } from "@/hooks/use-toast"

export default function MaintenanceForecastPage() {
  const { toast } = useToast()
  const router = useRouter()
  const [selectedQuarter, setSelectedQuarter] = useState("Q1")
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [groupByPart, setGroupByPart] = useState(true)
  const [expandedParts, setExpandedParts] = useState<Record<string, boolean>>({})

  // Check authentication on page load
  useEffect(() => {
    // In a real app, this would check a token or session
    const loggedIn = localStorage.getItem("isLoggedIn") === "true"
    setIsLoggedIn(loggedIn)

    if (!loggedIn) {
      toast({
        title: "Authentication Required",
        description: "Please log in to view this page",
      })
      router.push("/login")
    }
  }, [router, toast])

  // Sample forecast data organized by quarters
  const forecastData = {
    Q1: {
      predictedIssues: [
        {
          part: "Brake Pads",
          vin: "4T1BF1FK5GU123456",
          quantity: 4,
          owner: "John Smith",
          description: "Brake pads will need replacement within 2 months",
        },
        {
          part: "Brake Pads",
          vin: "WBAJB9C51BC578123",
          quantity: 4,
          owner: "Sarah Johnson",
          description: "Brake pads showing significant wear",
        },
        {
          part: "Battery",
          vin: "4T1BF1FK5GU123456",
          quantity: 1,
          owner: "John Smith",
          description: "Battery showing signs of decreased performance",
        },
        {
          part: "Battery",
          vin: "1HGCM82633A123456",
          quantity: 1,
          owner: "Michael Brown",
          description: "Battery capacity below 60%",
        },
        {
          part: "Suspension System",
          vin: "4T1BF1FK5GU123456",
          quantity: 1,
          owner: "John Smith",
          description: "Suspension system may need inspection based on driving patterns",
        },
      ],
      maintenanceCosts: {
        last6Months: "$850",
        next6MonthsEstimate: "$1,200",
      },
    },
    Q2: {
      predictedIssues: [
        {
          part: "Timing Belt",
          vin: "WBAJB9C51BC578123",
          quantity: 1,
          owner: "Sarah Johnson",
          description: "Timing belt showing signs of wear, replacement recommended",
        },
        {
          part: "Water Pump",
          vin: "WBAJB9C51BC578123",
          quantity: 1,
          owner: "Sarah Johnson",
          description: "Water pump efficiency decreasing, potential replacement needed",
        },
        {
          part: "Water Pump",
          vin: "5YJSA1E47JF123456",
          quantity: 1,
          owner: "Emily Davis",
          description: "Water pump showing early signs of leakage",
        },
        {
          part: "Spark Plugs",
          vin: "WBAJB9C51BC578123",
          quantity: 6,
          owner: "Sarah Johnson",
          description: "Spark plugs reaching end of service life",
        },
        {
          part: "Spark Plugs",
          vin: "1G1JC5SH4D4123456",
          quantity: 4,
          owner: "Jennifer Martinez",
          description: "Spark plugs showing reduced efficiency",
        },
        {
          part: "Air Filter",
          vin: "1HGCM82633A123456",
          quantity: 1,
          owner: "Michael Brown",
          description: "Air filter clogging detected, replacement needed",
        },
      ],
      maintenanceCosts: {
        last6Months: "$1,200",
        next6MonthsEstimate: "$2,500",
      },
    },
    Q3: {
      predictedIssues: [
        {
          part: "Transmission Fluid",
          vin: "5YJSA1E47JF123456",
          quantity: 1,
          owner: "Emily Davis",
          description: "Transmission fluid degradation detected, flush recommended",
        },
        {
          part: "Radiator",
          vin: "5YJSA1E47JF123456",
          quantity: 1,
          owner: "Emily Davis",
          description: "Radiator showing early signs of leakage",
        },
        {
          part: "Brake Rotors",
          vin: "JN1AZ0CP8BT123456",
          quantity: 2,
          owner: "Robert Wilson",
          description: "Front brake rotors approaching minimum thickness",
        },
        {
          part: "Brake Rotors",
          vin: "3VWSE69M35M123456",
          quantity: 2,
          owner: "David Thompson",
          description: "Brake rotors showing uneven wear pattern",
        },
      ],
      maintenanceCosts: {
        last6Months: "$950",
        next6MonthsEstimate: "$1,800",
      },
    },
    Q4: {
      predictedIssues: [
        {
          part: "Alternator",
          vin: "1G1JC5SH4D4123456",
          quantity: 1,
          owner: "Jennifer Martinez",
          description: "Alternator output decreasing, replacement may be needed",
        },
        {
          part: "Fuel Pump",
          vin: "1G1JC5SH4D4123456",
          quantity: 1,
          owner: "Jennifer Martinez",
          description: "Fuel pump pressure fluctuations detected",
        },
        {
          part: "Fuel Pump",
          vin: "JN1AZ0CP8BT123456",
          quantity: 1,
          owner: "Robert Wilson",
          description: "Fuel pump showing signs of wear",
        },
        {
          part: "Oxygen Sensors",
          vin: "1G1JC5SH4D4123456",
          quantity: 2,
          owner: "Jennifer Martinez",
          description: "Oxygen sensors showing reduced efficiency",
        },
        {
          part: "Wheel Bearings",
          vin: "3VWSE69M35M123456",
          quantity: 2,
          owner: "David Thompson",
          description: "Front wheel bearings showing signs of wear",
        },
        {
          part: "Serpentine Belt",
          vin: "3VWSE69M35M123456",
          quantity: 1,
          owner: "David Thompson",
          description: "Serpentine belt approaching end of service life",
        },
      ],
      maintenanceCosts: {
        last6Months: "$1,100",
        next6MonthsEstimate: "$2,200",
      },
    },
  }

  const currentQuarterData = forecastData[selectedQuarter]

  // Group issues by part
  const groupedIssues = currentQuarterData.predictedIssues.reduce(
    (acc, issue) => {
      if (!acc[issue.part]) {
        acc[issue.part] = []
      }
      acc[issue.part].push(issue)
      return acc
    },
    {} as Record<string, typeof currentQuarterData.predictedIssues>,
  )

  // Toggle expansion for a specific part
  const togglePartExpansion = (part: string) => {
    setExpandedParts((prev) => ({
      ...prev,
      [part]: !prev[part],
    }))
  }

  if (!isLoggedIn) {
    return null // Will redirect in useEffect
  }

  return (
    <div className="container px-4 py-12 mx-auto md:px-6 bg-gray-900 min-h-screen">
      <Link href="/" className="inline-flex items-center text-gray-400 hover:text-white mb-8">
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Home
      </Link>

      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center p-4 bg-gray-800 rounded-full mb-4">
            <LineChart className="h-10 w-10 text-green-600" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-4">Maintenance Demand Forecast</h1>
          <p className="text-gray-300 max-w-2xl mx-auto">
            Predict future maintenance needs based on your vehicle's data and usage patterns to avoid unexpected
            breakdowns.
          </p>
        </div>

        <div className="mb-8">
          <div className="flex flex-wrap gap-2 justify-center">
            {Object.keys(forecastData).map((quarter) => (
              <Button
                key={quarter}
                variant={selectedQuarter === quarter ? "default" : "outline"}
                className={
                  selectedQuarter === quarter
                    ? "bg-green-700 hover:bg-green-800"
                    : "border-gray-600 text-gray-300 hover:bg-gray-700"
                }
                onClick={() => setSelectedQuarter(quarter)}
              >
                {quarter}
              </Button>
            ))}
          </div>
        </div>

        <Card className="bg-gray-800 border-gray-700 mb-6">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-white">Predicted Issues - {selectedQuarter}</CardTitle>
              <CardDescription className="text-gray-400">
                Potential problems identified by our predictive maintenance system for {selectedQuarter}
              </CardDescription>
            </div>
            <Button
              variant="outline"
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
              onClick={() => setGroupByPart(!groupByPart)}
            >
              {groupByPart ? "Show All Issues" : "Group By Part"}
            </Button>
          </CardHeader>
          <CardContent>
            {groupByPart ? (
              <div className="rounded-md border border-gray-700 overflow-hidden">
                <Table>
                  <TableHeader className="bg-gray-700">
                    <TableRow className="hover:bg-gray-700/50 border-gray-600">
                      <TableHead className="text-gray-300">Part</TableHead>
                      <TableHead className="text-gray-300">Total Quantity</TableHead>
                      <TableHead className="text-gray-300">Owners</TableHead>
                      <TableHead className="text-gray-300">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {Object.entries(groupedIssues).map(([part, issues]) => (
                      <>
                        <TableRow key={part} className="hover:bg-gray-700/50 border-gray-600">
                          <TableCell className="font-medium text-white">{part}</TableCell>
                          <TableCell className="text-gray-300">
                            {issues.reduce((sum, issue) => sum + issue.quantity, 0)}
                          </TableCell>
                          <TableCell className="text-gray-300">
                            {issues.length} {issues.length === 1 ? "owner" : "owners"}
                          </TableCell>
                          <TableCell>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="text-green-500 hover:text-green-400 hover:bg-gray-700 p-0 h-8 w-8"
                              onClick={() => togglePartExpansion(part)}
                            >
                              {expandedParts[part] ? (
                                <ChevronUp className="h-5 w-5" />
                              ) : (
                                <ChevronDown className="h-5 w-5" />
                              )}
                            </Button>
                          </TableCell>
                        </TableRow>
                        {expandedParts[part] && (
                          <TableRow className="bg-gray-700/30 border-gray-600">
                            <TableCell colSpan={4} className="p-0">
                              <Table>
                                <TableHeader className="bg-gray-700/50">
                                  <TableRow className="hover:bg-gray-700/50 border-gray-600">
                                    <TableHead className="text-gray-400 text-xs">Owner</TableHead>
                                    <TableHead className="text-gray-400 text-xs">VIN</TableHead>
                                    <TableHead className="text-gray-400 text-xs">Quantity</TableHead>
                                    <TableHead className="text-gray-400 text-xs">Description</TableHead>
                                  </TableRow>
                                </TableHeader>
                                <TableBody>
                                  {issues.map((issue, idx) => (
                                    <TableRow key={idx} className="hover:bg-gray-700/70 border-gray-600/50">
                                      <TableCell className="text-white text-sm py-2">{issue.owner}</TableCell>
                                      <TableCell className="text-gray-300 font-mono text-xs py-2">
                                        {issue.vin}
                                      </TableCell>
                                      <TableCell className="text-gray-300 text-sm py-2">{issue.quantity}</TableCell>
                                      <TableCell className="text-gray-300 text-sm py-2">{issue.description}</TableCell>
                                    </TableRow>
                                  ))}
                                </TableBody>
                              </Table>
                            </TableCell>
                          </TableRow>
                        )}
                      </>
                    ))}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <div className="rounded-md border border-gray-700 overflow-hidden">
                <Table>
                  <TableHeader className="bg-gray-700">
                    <TableRow className="hover:bg-gray-700/50 border-gray-600">
                      <TableHead className="text-gray-300">Part</TableHead>
                      <TableHead className="text-gray-300">VIN</TableHead>
                      <TableHead className="text-gray-300">Quantity</TableHead>
                      <TableHead className="text-gray-300">Owner</TableHead>
                      <TableHead className="text-gray-300 w-1/3">Description</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {currentQuarterData.predictedIssues.map((issue, index) => (
                      <TableRow key={index} className="hover:bg-gray-700/50 border-gray-600">
                        <TableCell className="font-medium text-white">{issue.part}</TableCell>
                        <TableCell className="text-gray-300 font-mono text-sm">{issue.vin}</TableCell>
                        <TableCell className="text-gray-300">{issue.quantity}</TableCell>
                        <TableCell className="text-gray-300">{issue.owner}</TableCell>
                        <TableCell className="text-gray-300">{issue.description}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}

            <div className="mt-4 p-4 bg-gray-700 rounded-lg border border-gray-600">
              <div className="flex items-start gap-3 mb-3">
                <AlertTriangle className="h-5 w-5 text-orange-500 mt-0.5 shrink-0" />
                <p className="text-white font-medium">
                  {selectedQuarter} Forecast Summary: {Object.keys(groupedIssues).length} unique parts needed across{" "}
                  {currentQuarterData.predictedIssues.length} maintenance issues
                </p>
              </div>
              <p className="text-sm text-gray-300 ml-8">
                Based on historical data and usage patterns, these parts are likely to require maintenance or
                replacement during {selectedQuarter}. Planning ahead can reduce vehicle downtime and prevent cascading
                failures.
              </p>
            </div>
          </CardContent>
        </Card>

        <div className="grid gap-6 md:grid-cols-2">
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Maintenance Cost Forecast</CardTitle>
              <CardDescription className="text-gray-400">
                Estimated maintenance expenses based on vehicle condition and history
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-gray-700 p-4 rounded-lg text-center">
                  <p className="text-sm text-gray-400 mb-1">Last 6 Months</p>
                  <p className="text-2xl font-bold text-white">{currentQuarterData.maintenanceCosts.last6Months}</p>
                </div>
                <div className="bg-gray-700 p-4 rounded-lg text-center">
                  <p className="text-sm text-gray-400 mb-1">Next 6 Months (Est.)</p>
                  <p className="text-2xl font-bold text-white">
                    {currentQuarterData.maintenanceCosts.next6MonthsEstimate}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Recommended Actions</CardTitle>
              <CardDescription className="text-gray-400">
                Steps to take based on the maintenance forecast
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-start gap-3 bg-gray-700 p-3 rounded-lg">
                  <Calendar className="h-5 w-5 text-green-600 mt-0.5 shrink-0" />
                  <div>
                    <p className="text-white font-medium">Schedule Preventive Maintenance</p>
                    <p className="text-sm text-gray-300">
                      Book appointments for predicted issues to avoid emergency repairs
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3 bg-gray-700 p-3 rounded-lg">
                  <CheckCircle className="h-5 w-5 text-green-600 mt-0.5 shrink-0" />
                  <div>
                    <p className="text-white font-medium">Order Parts in Advance</p>
                    <p className="text-sm text-gray-300">Pre-order high-demand parts to avoid supply chain delays</p>
                  </div>
                </div>
                <div className="flex items-start gap-3 bg-gray-700 p-3 rounded-lg">
                  <Info className="h-5 w-5 text-blue-500 mt-0.5 shrink-0" />
                  <div>
                    <p className="text-white font-medium">Budget Planning</p>
                    <p className="text-sm text-gray-300">
                      Allocate resources based on the quarterly maintenance forecast
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
