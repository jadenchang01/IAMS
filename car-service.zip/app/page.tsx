"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { ScanLine, ClipboardList, LineChart, Menu } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

export default function Home() {
  const [currentSlide, setCurrentSlide] = useState(0)
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [username, setUsername] = useState("User")

  // Slideshow animation
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev === 2 ? 0 : prev + 1))
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  // Check login status when component mounts
  useEffect(() => {
    const loggedIn = localStorage.getItem("isLoggedIn") === "true"
    setIsLoggedIn(loggedIn)

    // In a real app, you would fetch the user's name from your auth system
    // For demo purposes, we'll use a hardcoded name
    if (loggedIn) {
      const storedUsername = localStorage.getItem("username")
      if (storedUsername) {
        setUsername(storedUsername)
      }
    }
  }, [])

  const services = [
    {
      id: "scan-registration",
      title: "Scan & Registration",
      description: "Quick vehicle scanning and registration services.",
      icon: <ScanLine className="w-10 h-10 text-green-600" />,
    },
    {
      id: "maintenance-log",
      title: "Maintenance Log",
      description: "Track and manage your vehicle's maintenance history.",
      icon: <ClipboardList className="w-10 h-10 text-green-600" />,
    },
    {
      id: "maintenance-forecast",
      title: "Maintenance Demand Forecast",
      description: "Predict future maintenance needs based on vehicle data.",
      icon: <LineChart className="w-10 h-10 text-green-600" />,
    },
  ]

  return (
    <div className="flex flex-col min-h-screen bg-gray-900">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-gray-800 border-b border-gray-700">
        <div className="container flex items-center justify-between h-16 px-4 mx-auto md:px-6">
          <div className="flex items-center gap-2">
            <ScanLine className="w-6 h-6 text-green-600" />
            <span className="text-xl font-bold text-white">AutoCare Center</span>
          </div>
          <div className="flex items-center gap-4">
            {isLoggedIn ? (
              <div className="flex items-center gap-2">
                <span className="text-white hidden md:inline">Welcome, {username}</span>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button className="bg-green-700 hover:bg-green-800 text-white">{username}</Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="bg-gray-800 text-white border-gray-700">
                    <DropdownMenuItem className="hover:bg-gray-700 focus:bg-gray-700 cursor-pointer">
                      <Link href="/profile" className="w-full">
                        Profile
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      className="hover:bg-gray-700 focus:bg-gray-700 cursor-pointer"
                      onClick={() => {
                        localStorage.removeItem("isLoggedIn")
                        setIsLoggedIn(false)
                        window.location.reload()
                      }}
                    >
                      Log Out
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            ) : (
              <Link href="/login">
                <Button className="bg-green-700 hover:bg-green-800 text-white">Log In</Button>
              </Link>
            )}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="text-white">
                  <Menu className="w-5 h-5" />
                  <span className="sr-only">Menu</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="bg-gray-800 text-white border-gray-700">
                <DropdownMenuItem className="hover:bg-gray-700 focus:bg-gray-700 cursor-pointer">
                  <Link href="/services/scan-registration" className="w-full">
                    Scan & Registration
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem className="hover:bg-gray-700 focus:bg-gray-700 cursor-pointer">
                  <Link href="/services/maintenance-log" className="w-full">
                    Maintenance Log
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem className="hover:bg-gray-700 focus:bg-gray-700 cursor-pointer">
                  <Link href="/services/maintenance-forecast" className="w-full">
                    Maintenance Demand Forecast
                  </Link>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </header>

      {/* Slideshow Section */}
      <section className="relative w-full h-64 md:h-80 lg:h-96 overflow-hidden">
        {[
          "/placeholder.svg?height=600&width=1200",
          "/placeholder.svg?height=600&width=1200",
          "/placeholder.svg?height=600&width=1200",
        ].map((src, index) => (
          <div
            key={index}
            className={`absolute inset-0 w-full h-full transition-opacity duration-1000 ease-in-out ${
              currentSlide === index ? "opacity-100" : "opacity-0"
            }`}
          >
            <div className="w-full h-full bg-cover bg-center" style={{ backgroundImage: `url(${src})` }} />
            <div className="absolute inset-0 bg-black/50" />
            <div className="absolute inset-0 flex items-center justify-center">
              <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white text-center px-4">
                {index === 0
                  ? "Professional Auto Services"
                  : index === 1
                    ? "Expert Maintenance"
                    : "Digital Vehicle Management"}
              </h2>
            </div>
          </div>
        ))}

        {/* Slideshow indicators */}
        <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-2">
          {[0, 1, 2].map((index) => (
            <button
              key={index}
              className={`w-3 h-3 rounded-full ${currentSlide === index ? "bg-green-600" : "bg-gray-400"}`}
              onClick={() => setCurrentSlide(index)}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 bg-gray-800 flex-grow">
        <div className="container px-4 mx-auto md:px-6">
          <div className="flex flex-col items-center mb-12 text-center">
            <h2 className="text-3xl font-bold text-white">Our Services</h2>
            <p className="max-w-2xl mt-4 text-gray-300">
              We offer a comprehensive range of automotive services to keep your vehicle running smoothly.
            </p>
          </div>
          <div className="grid gap-6 md:grid-cols-3">
            {services.map((service) => (
              <Link
                href={`/services/${service.id}`}
                key={service.id}
                className="block transition-transform hover:scale-105"
              >
                <Card className="h-full bg-gray-700 border-gray-600 hover:shadow-lg hover:shadow-green-900/20 cursor-pointer">
                  <CardHeader>
                    <div className="p-2 w-16 h-16 flex items-center justify-center rounded-full bg-gray-600 mb-4">
                      {service.icon}
                    </div>
                    <CardTitle className="text-white">{service.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-300">{service.description}</p>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 text-white bg-gray-950">
        <div className="container px-4 mx-auto md:px-6">
          <div className="grid gap-8 md:grid-cols-3">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <ScanLine className="w-6 h-6 text-green-600" />
                <span className="text-xl font-bold">AutoCare Center</span>
              </div>
              <p className="text-gray-400">Your trusted partner for all your automotive service needs.</p>
            </div>
            <div>
              <h3 className="mb-4 text-lg font-bold">Services</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/services/scan-registration" className="text-gray-400 hover:text-white transition-colors">
                    Scan & Registration
                  </Link>
                </li>
                <li>
                  <Link href="/services/maintenance-log" className="text-gray-400 hover:text-white transition-colors">
                    Maintenance Log
                  </Link>
                </li>
                <li>
                  <Link
                    href="/services/maintenance-forecast"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    Maintenance Demand Forecast
                  </Link>
                </li>
                <li>
                  <Link href="/services" className="text-gray-400 hover:text-white transition-colors">
                    All Services
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="mb-4 text-lg font-bold">Contact</h3>
              <address className="not-italic text-gray-400">
                123 Auto Center Drive
                <br />
                Anytown, USA 12345
                <br />
                <Link href="tel:+15551234567" className="hover:text-white transition-colors">
                  (555) 123-4567
                </Link>
                <br />
                <Link href="mailto:info@autocarecenter.com" className="hover:text-white transition-colors">
                  info@autocarecenter.com
                </Link>
              </address>
            </div>
          </div>
          <div className="pt-8 mt-8 border-t border-gray-800">
            <p className="text-center text-gray-400">
              © {new Date().getFullYear()} AutoCare Center. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
